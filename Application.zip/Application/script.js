var selectedRow = null

function onFormSubmit(){
    var formData = readFormData();
    if(selectedRow == null)
        insertNewRecord(formData);
    else
        updateRecord(formData);
    resetForm();

}

function readFormData(){
    var formData = {};
    formData["full_name"]  = document.getElementById("full_name").value;
    formData["stud_id"]  = document.getElementById("stud_id").value;
    formData["branch"]  = document.getElementById("branch").value;
    formData["sem"]  = document.getElementById("sem").value;
    return formData;
}

function insertNewRecord(data){
    var table = document.getElementById("studentlist").getElementsByTagName('tbody')[0];
    var newRow  = table.insertRow(table.length);
    cell1 = newRow.insertCell(0);
    cell1.innerHTML = data.full_name
    cell2 = newRow.insertCell(1);
    cell2.innerHTML = data.stud_id
    cell3 = newRow.insertCell(2);
    cell3.innerHTML = data.branch
    cell4 = newRow.insertCell(3);
    cell4.innerHTML = data.sem
    cell4 = newRow.insertCell(4)
    cell4.innerHTML = '<a href="#" onclick="onEdit(this)" >Edit</a> <a href="#" onclick="onDelete(this)">Delete</a>';


}
function resetForm(){
    document.getElementById("full_name").value="";
    document.getElementById("stud_id").value="";
    document.getElementById("branch").value="";
    document.getElementById("sem").value="";
    selectedRow = null;
}

function onEdit(td){
    selectedRow = td.parentElement.parentElement;
    document.getElementById("full_name").value = selectedRow.cells[0].innerHTML;
    document.getElementById("stud_id").value = selectedRow.cells[1].innerHTML;
    document.getElementById("branch").value = selectedRow.cells[2].innerHTML;
    document.getElementById("sem").value = selectedRow.cells[3].innerHTML;
}

function updateRecord(formData){
    selectedRow.cells[0].innerHTML = formData.full_name;
     selectedRow.cells[1].innerHTML = formData.stud_id;
      selectedRow.cells[2].innerHTML = formData.branch;
       selectedRow.cells[3].innerHTML = formData.sem;
    
}
function onDelete(td){
    if(confirm("Are you sure to delete this record..?")){
    row = td.parentElement.parentElement;
    document.getElementById('studentlist').deleteRow(row.rowIndex);
    resetForm();
    }
}

   


    